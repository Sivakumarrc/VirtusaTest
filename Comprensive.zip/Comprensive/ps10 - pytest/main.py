import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
import pytest


def test_navigation():
    driver = webdriver.Chrome()
    driver.get("https://www.automationanywhere.com/")
    driver.maximize_window()
    time.sleep(5)
    driver.refresh()

    time.sleep(5)

    products = driver.find_element_by_xpath('//a[contains(text(),"Products")]')
    actions = ActionChains(driver)
    actions.move_to_element(products).perform()

    time.sleep(2)
    process_discovery = driver.find_element_by_xpath('//a[@href="/products/process-discovery"]')
    process_discovery.click()

    # Verify that its navigating to following URL
    time.sleep(2)
    assert driver.current_url == "https://www.automationanywhere.com/products/process-discovery"
    print("Navigated to Process Discovery page successfully")

    driver.quit()

if __name__ == "__main__":
    test_navigation()
