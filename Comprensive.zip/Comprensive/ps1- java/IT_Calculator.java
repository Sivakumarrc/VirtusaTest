package Assignment;

import java.util.Scanner;

public class IT_Calculator {
    double TaxableIncome, TaxPaidPerYear, TaxPayablePerMonth;

    public static void main(String[] args) {
        IT_Calculator calc = new IT_Calculator();
        calc.calculateTax();
    }

    public void calculateTax() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your Taxable Income: ");
        TaxableIncome = scanner.nextDouble();

        if (TaxableIncome <= 25000) {
            TaxPaidPerYear = TaxableIncome * 0.00;
        } else if (TaxableIncome > 25000 && TaxableIncome <= 50000) {
            TaxPaidPerYear = TaxableIncome * 0.10;
        } else if (TaxableIncome > 50000 && TaxableIncome <= 75000) {
            TaxPaidPerYear = TaxableIncome * 0.20;
        } else {
            TaxPaidPerYear = TaxableIncome * 0.30;
        }

        TaxPayablePerMonth = TaxPaidPerYear / 12;

        System.out.println("Tax paid in a Year: " + TaxPaidPerYear);
        System.out.println("Tax should pay in a month: " + TaxPayablePerMonth);
    }
}