import math


class CircleComp:
    def __init__(self):
        self.radius = 0
        self.diameter = 0
        self.circumference = 0
        self.area = 0

    def calculate(self):
        self.radius = float(input("Enter radius: "))
        self.diameter = self.radius * 2.0
        self.circumference = 2 * math.pi * self.radius
        self.area = math.pi * self.radius * self.radius

        print("Diameter: ", self.diameter)
        print("Circumference: ", self.circumference)
        print("Area: ", self.area)


CircleComp().calculate()
